package org.generation.CoffeeKode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoffeeKodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoffeeKodeApplication.class, args);
	}

}
